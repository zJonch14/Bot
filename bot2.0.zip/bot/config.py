PREFIX = '!'
TOKEN_FILE = 'tokens/token.txt'
